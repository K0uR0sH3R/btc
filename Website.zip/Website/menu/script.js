$(document).ready(function() {
});

$(".sidebar ul li").on("click", function() {
  if ($(this).hasClass("active")) {

  } else {
    var option = $(this).data("option");
    $(".sidebar ul li.active").removeClass("active");
    $(this).addClass("active");
    $(".active[data-menu]").removeClass("active");
    $("[data-menu='" + option + "']").addClass("active");
  }
});